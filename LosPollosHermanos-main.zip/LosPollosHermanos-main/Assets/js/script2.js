 // Obtém o modal e o botão de fechar
 const modal = document.getElementById("modal");
 const closeModal = document.querySelector(".close");
 const svgIcon = document.getElementById("openModal");
 
 // Quando o SVG for clicado, abre o modal
 svgIcon.onclick = function() {
   modal.style.display = "block";
 }
 
 // Quando o botão de fechar for clicado, fecha o modal
 closeModal.onclick = function() {
   modal.style.display = "none";
 }
 
 // Fecha o modal se o usuário clicar fora da área do modal
 window.onclick = function(event) {
   if (event.target == modal) {
     modal.style.display = "none";
   }
 }
 