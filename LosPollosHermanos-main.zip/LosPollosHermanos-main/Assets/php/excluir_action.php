<?php
session_start();

require_once('../conexao/conexao.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = trim($_POST['senha']);
    $confirmar_senha = trim($_POST['confirmar_senha']);

    if (empty($nome) || empty($email) || empty($senha) || empty($confirmar_senha)) {
        echo "<script>alert('Todos os campos são obrigatórios.'); window.history.back();</script>";
        exit();
    }

    if ($senha !== $confirmar_senha) {
        echo "<script>alert('As senhas não coincidem!'); window.history.back();</script>";
        exit();
    }

    $mysql = new BancodeDados();
    $mysql->conecta();

    $sql = "SELECT * FROM tbusuario WHERE email = ? AND nome = ?";
    $stmt = $mysql->con->prepare($sql);
    $stmt->bind_param("ss", $email, $nome);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if ($senha === $user['senha']) {
            $delete_sql = "DELETE FROM tbusuario WHERE email = ? AND nome = ?";
            $delete_stmt = $mysql->con->prepare($delete_sql);
            $delete_stmt->bind_param("ss", $email, $nome);

            if ($delete_stmt->execute()) {
                echo "<script>alert('Conta excluída com sucesso!'); window.location.href = '../../index.html';</script>";
            } else {
                echo "<script>alert('Erro ao excluir a conta.'); window.history.back();</script>";
            }
        } else {
            echo "<script>alert('Senha incorreta!'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Conta não encontrada!'); window.history.back();</script>";
    }

    $stmt->close();
}
?>
